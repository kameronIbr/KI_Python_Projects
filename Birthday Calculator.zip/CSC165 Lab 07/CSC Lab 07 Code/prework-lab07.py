
months = ['jan','feb','mar','apr','may','jun',
          'jul','aug','sep','oct','nov','dec']

days_in_months = [ 31, 28, 31, 30, 31, 30,
                  31, 31, 30, 31, 30, 31 ]


def get_input_month():
    while True:
        month = input('Please enter a month: ').lower()
        if month in months:
            return month
        else:
            print('Incorrect')
    pass

def days_in(month):
    index = months.index(month)
    return days_in_months[index]

    pass

def print_months(start,end):
    start_index = months.index(start.lower())
    end_index = months.index(end.lower())
    
    while start_index != end_index:
        print(months[start_index].capitalize(), end=" ")
        start_index = (start_index + 1) % 12
    print(months[start_index].capitalize())
    pass

def print_months_days(start,end):
    start_index = months.index(start.lower())
    end_index = months.index(end.lower())
    
    while True:
        month = months[start_index].capitalize()
        days = days_in_months[start_index]
        print(f"{month} ({days})")
        if start_index == end_index:
            break
        start_index = (start_index + 1) % 12
    pass


if __name__ == '__main__':
    m = get_input_month()
    d = days_in(m)
    print(f"Number of days in {m}: {d}")
    print_months('sep','apr')
    print_months_days('nov','feb')
    
