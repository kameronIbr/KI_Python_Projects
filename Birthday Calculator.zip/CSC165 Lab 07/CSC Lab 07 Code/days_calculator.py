from datetime import date
from get_input import *


months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun',
          'jul', 'aug', 'sep', 'oct', 'nov', 'dec']

days_in_months = [ 31, 28, 31, 30, 31, 30,
                  31, 31, 30, 31, 30, 31 ]

'''
Dates will be stored as a list in this order: [ month, day, year ]
So,
- date[0] is the month
- date[1] is the day
- date[2] is the year
'''

def get_today():
    '''
    Use the imported date module to get today's date
    then parse into month day year
    '''
    year = date.today().year
    month_no = date.today().month
    month = months[month_no-1]
    day = date.today().day

    return [ month, day, year ]

def print_date(adate):
    '''
    Nicely format the date. Could be month+day or month+day+year
    '''
    month = adate[0].lower()
    day = adate[1]
    # include the year too, if it is part of the date
    if len(adate)==3:
        print(f'{month} {day}, {adate[2]}')
    else:
        print(f'{month} {day}')

def get_month_day():
    '''
    From the user, get a month and a day.
    The month must be Jan to Dec
    and the days must be valid for the given month
    '''
    month = get_string_inlist(months)
    max_days = days_in_months[months.index(month)]
    day = get_int_inrange(1, max_days)
    return month, day
    
    # determine range of days for given month
    ## (#2) FIX THIS VARIABLE ASSIGNMENT
    return month, day
    

def get_date():
    '''
    From the user, get a month, day, and year.
    The called functions check the validity of the user input.
    '''
    month, day = get_month_day()
    year = get_int_inrange(1890,9999)
    return [month, day, year]

### (#3) ___________ PRIMARY BASE LEVEL REQUIREMENT ______________

def age(birthdate):
    '''
    Calculates the age given a birth date. Returns the age in years.
    '''
    today = get_today()
    birth_month = birthdate[0].lower()
    today_month = today[0].lower()
    
    birth_day = birthdate[1]
    today_day = today[1]
    
    # Print the values of birthdate and today for debugging
    print("Birthdate:", birthdate)
    print("Today:", today)

    # Check if today is the birthday
    if today_month == birth_month and today_day == birth_day:
        print("Happy Birthday!!!")
        return 0

    age = today[2] - birthdate[2]

    # Adjust the age if the birthday hasn't occurred yet this year
    if (today_month, today_day) < (birth_month, birth_day):
        age -= 1

    return age


    # determine birth and today month indices (in range 0 to 11)

    # first, let us check if today is the birthday

        #print("H a p p y  B i r t h d a y ! ! !")
        # return age



    # The age is different depending on whether the birthday has
    # already passed this year or is coming up.
    
    # Calculate the age in years

    return years

## __________________________________________________
## ______________________   LEVEL UP  _______________

### (#4)
def days_between_months(first_month, second_month):
    '''
    Assumes that first and second month are different.
    
    Sum the days in all months between first and second.
    Both the first and second are exclusive!

    Months are entered as strings. Assume values are in the months list.
    '''

    # determine the indices of the 2 months passed to the function
    first_i = months.index(first_month.lower())
    second_i = months.index(second_month.lower())
    # start at the month after the first, since it is exclusive
    start_index = first_i = +1
    # initialize the sum of days between the 2 months
    days = 0

    # iterate over the months
    for index in range(start_index, second_i):
        # determine days in that month and add to the sum
        days += days_in_months[index]
    return days


### (#5)
def days_between_dates(first, second):
    '''
    Calculate the days between the first and second date IGNORING THE YEAR
    Dates are [month, day, year]
    Note that the date might cross the "year", for example Sep 27 to Jun 28
    '''

    first_month, first_day, *first_year = first
    second_month, second_day, *second_year = second

    # If the months are the same
    if first_month == second_month:
        if first_day < second_day:
            # If the first day is earlier, then it's the difference
            days = second_day - first_day
        elif first_day > second_day:
            # If the first day is later, then it is 365 - difference
            days = 365 - (first_day - second_day)
        else:
            # They are the same and there are 0 days between
            days = 0
    else:
        # If months are not the same
        # Days between the months
        days = days_between_months(first_month, second_month)
        
        # Days in the first month (those after the given day)
        days += days_in_months[months.index(first_month.lower())] - first_day
        
        # Days in the second month
        days += second_day
    
    return days



#### (#1) Add an if-statement to execute code when debugging module
birthdate = ['mar', 7, 2024]
if __name__ == '__main__':
	today = get_today()
	print_date(today)
	date1 = get_month_day()
	print_date(date1)
	date2 = get_date()
	print_date(date2)
	result = age(birthdate)
	print("Age:", result)




            




