import turtle
import random
import math
import setup

from setup import *
def run_the_race(runner_count):
    '''
    Race turtles against each other in a sprint (straight track, not oval).
    It makes use of the setup in setup.py
    The user specifies the number of competitors, then competitors
    race to the finish line.

    VARIABLES:
    - runner_count: (parameter) the number of turtles running the race
    - writer: the turtle that writes text onto the graphics window
    - daisy, lemon, jojo: 3 turtles for the 3 competitors racing
    - starter_row: in setup.py. Marks the starting line of the race
    - finish_row: in setup.py. Marks the finish line of the race
    - finished: list of finishers of the race, in order

    FUNCTIONS:
    - setup_sprinting() in setup.py. Sets the track.
    - make_competitor() in setup.py. Creates a turtle.
    '''
    
    writer = turtle.Turtle()
    writer.hideturtle()
    
    # go to printing text
    writer.pu()
    writer.goto(-100,-150)

    setup_sprinting()


    # Create as many competitors as user indicated.
    competitors = []
    
    for i in range(runner_count):
        # Calculate the x-coordinate to evenly distribute competitors across the width of the track
        x_coordinate = -track_width // 2 + i * (track_width / (runner_count - 1))
        competitor_color = competitor_info[i][1]
        competitor = make_competitor(x_coordinate, starter_row, ['black', competitor_color])
        competitor.penup()
        competitors.append(competitor)
        writer.pu()
        writer.goto(competitor.xcor(), starter_row - 50 - 30 * (i % 2))
        writer.pd()
        writer.write(competitor_info[i][0], font=('Arial', 24, 'normal'))

    '''  STEP 1
    Place the competitors into a list called "competitors"
    '''

    ''' STEP 7
    Print competitor information to the screen using a for loop.
    Try to evenly space the competitors. Note that every other line
    is printed at a different row.
    '''

    # keep track of how many finished and in what order
    finished = []
    
    # once they have all crossed the finish line, the race is over
    while len(finished) < runner_count:
        for i in range(len(competitors)):
            competitor = competitors[i]
            # Move only if not finished the race
            if competitor_info[i][0] not in finished:
                # move forward a random amount
                delta = random.randint(1, 9)
                competitor.forward(delta)
                # check if they crossed the finish line
                if competitor.pos()[1] >= finish_row:
                    finished.append(competitor_info[i][0])
                    finished.append(competitor_info[i][0])

        '''
        _________________________
        STEP 6
        Nest a for-loop inside this while loop to move each
        competitor forward some random distance at each iteration.
        The for loop is a counting loop that iterates as many times
        as there are runners. You must use range because you will use
        the index value to access different lists.

        Change the first if-statement so that it uses your for loop
        iterator, not a hard-coded index (e.g. [0]).

        DELETE the if-statements for 'Jojo' and 'Lemon'
        '''

        '''
        ________________________
        STEP 2
        Replace the VARIABLE daisy with the reference to
        daisy in the competitors list.
        Just do this for Daisy for now.
        '''

        '''
        ________________________
        STEP 3
        Replace the STRING Daisy with a reference to the name
        in the competitor_info (in setup).
        '''

    writer.pu()
    writer.goto(-20,finish_row+50)
    writer.pd()
    writer.write(f'The winner is {finished[0]}!!',False,font=('Arial',24,'normal'))

    return finished

if __name__ == '__main__':
    run_the_race(3)
