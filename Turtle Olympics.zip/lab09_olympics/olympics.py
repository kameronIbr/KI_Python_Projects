from race import run_the_race
from shotput import go_shotput

# Define the range for the number of competitors
min_competitors = 3
max_competitors = 8

competitor_count = None

while competitor_count is None or competitor_count < min_competitors or competitor_count > max_competitors:
    try:
        competitor_count = int(input(f'How many competitors are there? (3 to 8) '))
        if competitor_count < min_competitors or competitor_count > max_competitors:
            print(f'Please enter a number between 3 and 8.')
    except ValueError:
        print('Invalid input. Please enter a valid number.')

run_the_race(competitor_count)
input('Enter to go to next event.')
go_shotput(competitor_count)
