import turtle
import random
import math
import setup

def awards_ceremony(competitors):
    podium_heights = [200, 150, 100]
    podium_colors = ['gold', 'silver', 'brown']
    podium_positions = [-150, 0, 150]

    podium_positions = [podium_positions[1], podium_positions[0], podium_positions[2]]

    medal_turtle = turtle.Turtle()
    medal_turtle.speed(0)
    medal_turtle.penup()
    
    counter = 0
    for height in podium_heights:
        podium = turtle.Turtle()
        podium.speed(0)
        podium.penup()
        podium.goto(podium_positions[counter], -setup.max_row)
        podium.pendown()
        podium.color(podium_colors[counter])
        podium.begin_fill()
        podium.left(90)
        podium.forward(height)
        podium.right(90)
        podium.forward(50)
        podium.right(90)
        podium.forward(height)
        podium.end_fill()
        podium.hideturtle()
        counter += 1

    for i in range(min(len(competitors), 3)):
        competitor_name = competitors[i][1]
        competitor_color = None
        for info in setup.competitor_info:
            if info[0] == competitor_name:
                competitor_color = info[1]
                break
        if competitor_color is None:
            continue

        competitor_x = podium_positions[i]
        competitor_y = -setup.max_row + podium_heights[i] + 40
        turtle.shape("turtle")
        turtle.shapesize(3)
        turtle.color('black', competitor_color)
        turtle.penup()
        turtle.goto(competitor_x, competitor_y)
        turtle.stamp()

        # Place medal around turtle's "neck"
        medal_color = podium_colors[i]
        medal_turtle.color(medal_color)  # Set the color for drawing the medal
        medal_turtle.goto(competitor_x + 10, competitor_y)  # Position the medal above the turtle's head
        medal_turtle.pendown()
        medal_turtle.begin_fill()
        if i == 3:  # Third place
            medal_turtle.circle(10)  
        else:
            medal_turtle.circle(10)  
        medal_turtle.end_fill()
        medal_turtle.penup()
        
def go_shotput(putters):
    setup.setup_shotput()  # Calling setup_shotput function from setup

    competitors = []

    for i in range(putters):
        startx = -setup.max_col + 50 + i * 50  # Adjust start position for each competitor
        starty = setup.ground_row + 20
        competitor_name = setup.competitor_info[i][0]
        competitor_color = setup.competitor_info[i][1]
        competitor = setup.make_competitor(startx, starty, ['black', competitor_color])
        competitors.append([0, competitor_name])

        offsetx = startx - 20
        offsety = starty + 20

        shot = turtle.Turtle()
        shot.speed(100)
        shot.hideturtle()
        shot.penup()
        shot.goto(offsetx, offsety)
        shot.color('black', 'black')
        shot.pendown()
        shot.begin_fill()
        shot.circle(10)
        shot.end_fill()

        angle = random.randint(10, 20)
        velocity = random.randint(40, 60)
        competitor.seth(angle)

        gravity = 9.81

        x = 0
        y = 0
        vx = velocity * math.cos(math.radians(angle))
        vy = velocity * math.sin(math.radians(angle))
        dt = 0.1

        while y >= -30:  # Continue until y is less than 0 but i set it as -30 so it touches the floor more noticeable
            shot.color(setup.sky_color, setup.sky_color)
            shot.begin_fill()
            shot.circle(12)
            shot.end_fill()
            shot.color('black', 'black')

            x = x + vx * dt
            y = y + vy * dt
            vy = vy - 0.5 * gravity * dt

            shot.pu()
            shot.goto(x + offsetx, y + offsety)
            shot.begin_fill()
            shot.circle(10)
            shot.end_fill()

        competitors[i][0] = x  # Record the distance thrown by each competitor

        # Mark the landing spot with a flag
        landing_flag = turtle.Turtle()
        landing_flag.speed(15)
        landing_flag.penup()
        landing_flag.goto(x + offsetx, y + offsety)
        landing_flag.color('black', competitor_color)  # Same color as the competitor
        landing_flag.begin_fill()
        landing_flag.circle(10)
        landing_flag.end_fill()
        
    # Sort competitors by the distance thrown
    competitors.sort(reverse=True)

    print("Shot Put Results:")
    for distance, name in competitors:
        print(f"{name} threw the shot put {round(distance, 2)} units.")
    winner = competitors[0][1]
    winner_text = turtle.Turtle()
    winner_text.speed(0)
    winner_text.penup()
    winner_text.goto(0, 100)
    # Position the text at the top of the window
    winner_text.color('red')
    winner_text.write(f"The winner is {winner}!", align="center", font=("Arial", 24, "normal"))
    awards_ceremony(competitors)
    turtle.done()

if __name__ == '__main__':
    go_shotput(3) 
