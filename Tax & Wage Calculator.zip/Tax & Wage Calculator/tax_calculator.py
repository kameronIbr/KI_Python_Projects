'''
This is "starter" code for Lab 05 Tax Calculator.
It asks for input from the user, then calculates taxes owed for the year.
The requirements document can be found by following the link on Moodle for lab05
'''

# Get information relevant to tax calculations
user_gross = float(input('What were your gross earnings in 2022? '))

print() # gives the output some space


#_____gathers the users gross earnings___________________________________________________
# Calculate FICA deduction based on income
#________________________________________________________

# Initialize FICA tax rates
ss_rate = 0.062
med_rate = 0.0145

#
fica_ss = user_gross*ss_rate
fica_med = user_gross*med_rate
fica = fica_ss + fica_med

print(f'FICA social security (at {ss_rate*100:.2f}%) = {fica_ss:.2f}')
print(f'FICA medicare (at {(med_rate*100):.2f}%) = {fica_med:.2f}')
print(f'FICA total = {fica:.2f}')
print()

#__code calculates and prints the SS tax, med tax, and total fica tax
#and the users gross income and tax rates______________________________________________________
# Calculate qualified dependent deduction
#________________________________________________________

#dep means dependent 
dep = 0
claim = 0
#c = claim
if user_gross < 200000:
    dep = int(input('How many dependents will you claim? '))
    claim = 2000 * dep
    print(f'You are receiving a ${claim:.2f} deduction for {dep} qualified dependents.')
else:
    print('Income is too high to claim dependents.')

print()

#________________________________________________________
# Calculate mortgage interest deduction
#________________________________________________________
#x = interest rate
interest = float(input('What is the interest rate (%) on your mortgage? '))/100
interest_paid = float(input('What was the total interest paid on your mortgage? '))
#y = interest paid
#m = mortgage
max_interest = interest*375000

#z = mortgage deduction
if interest_paid < max_interest:
    mortgage_deduct = interest_paid
    print(f'You can deduct {mortgage_deduct:.2f}, which is all of your paid interest.')
else:
    mortgage_deduct = max_interest
    print(f'You can deduct ${mortgage_deduct:.2f}, which is the maximum allowed.')
print()

#________________________________________________________
# Calculate adjusted income
#________________________________________________________
adjusted = user_gross - fica - claim - mortgage_deduct

print(f'Your gross income is ${user_gross:.2f}')
print(f'Your adjusted income is ${adjusted:.2f}')

# If negative, adjust to $0 adjusted income tax basis
if adjusted < 0:
    adjusted = 0
    print(f"But the govt doesn't owe you money. Your adjusted income is $0.")

print()

#__calculates adjusted income based on deductions
# and ensures adjusted income doesnt go below zero
#if adjusted income in below 0, it sets it to zero and tells user___________________________________________________
# calculate taxes based on tax bracket
#-----------------------------------------------------
'''
Tax Brackets
35% 275000+
32% 150000 to 275000
24%  50000 to 150000
14%  10500 to  50000
10%      0 to  10500
'''

taxes = 0
incomeInBracket = 0

# add calculated taxes in highest bracket $300,000+ (35%)
if adjusted > 275000:
    incomeInBracket = adjusted - 275000
    print(f'${incomeInBracket:10.2f} of your income is taxed at 35%.')
    taxes += incomeInBracket*0.35

# add calculated taxes in bracket $150k to $275k (32%)

if adjusted > 150000:
    if adjusted <= 275000:
        incomeInBracket = adjusted - 150000
    else:
        incomeInBracket = 275000 - 150000
    print(f'${incomeInBracket:10.2f} of your income is taxed at 32%.')
    taxes += incomeInBracket*0.34

# add calculated taxes in bracket $50k to $150k (24%)
# TODO:


if adjusted > 50000:
    if adjusted <= 150000:
        incomeInBracket = adjusted - 50000
    else:
        incomeInBracket = 150000 - 50000
    print(f'${incomeInBracket:10.2f} of your income is taxed at 24%.')
    taxes += incomeInBracket * 0.24

# fill this in to calculate income and taxes in this bracket
# remove the hashtag below when done to print your calculation
#    print(f'${incomeInBracket:10.2f} of your income is taxed at 24%.')

# add calculated taxes in bracket from $10,500 to $50k (14%)
# TODO:


if adjusted > 10500:
    if adjusted <= 50000:
        incomeInBracket = adjusted - 10500
    else:
        incomeInBracket = 50000 - 10500
    print(f'${incomeInBracket:10.2f} of your income is taxed at 14%.')
    taxes += incomeInBracket * 0.14

# fill this in to calculate income and taxes in this bracket
# remove the hashtag below when done to print your calculation
#    print(f'${incomeInBracket:10.2f} of your income is taxed at 14%.')
    
# calculate taxes in tax bracket $0 to $10,500 (10%)
# TODO:

if adjusted <= 10500:
    incomeInBracket = adjusted
    print(f'${incomeInBracket:10.2f} of your income is taxed at 10%.')
    taxes += incomeInBracket * 0.10

# fill this in to calculate income and taxes in this bracket
# remove the hashtag below when done to print your calculations
#    print(f'${incomeInBracket:10.2f} of your income is taxed at 10%.')

print()
print(f"You owe ${taxes:.2f} in federal taxes.")



    
