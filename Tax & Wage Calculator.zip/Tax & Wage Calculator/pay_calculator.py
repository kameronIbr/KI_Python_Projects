'''
Kameron Ibraheem
Lab05 Tax and Paycheck Calculator
INDIVIDUAL assignment

Calculate a paycheck amount based on information obtained from user.
Display relevant information to user.

Always have 2 numbers after the decimal for printing values.

Always describe the information in the print statement. For example,
do not just print "$534.00", print "Your gross earnings are $534.00"
'''

'''
___________________________________________________________________
BASE LEVEL REQUIREMENTS
You do not need to calculate witholding based on table.
-------------------------------------------------------------------
'''
# Ask user for hourly wage and hours worked
wage = float(input('What is your hourly wage? '))
worked = float(input('How many hours did you work this week? '))
# You will need to cast this to a float!


# Calculate gross earnings. Print results.

gross_earnings = wage * worked
print(f'Gross Earnings: ${gross_earnings:.2f}')

# Calculate social security and medicare contribution.
ss_rate = 0.062
med_rate = 0.0145

fica_ss = gross_earnings * ss_rate
fica_med = gross_earnings * med_rate
fica_total = fica_ss + fica_med

# Print EACH amount and the total FICA
print(f'FICA Social Security (at {ss_rate * 100:.2f}%) = ${fica_ss:.2f}')
print()
print(f'FICA Medicare (at {med_rate * 100:.2f}%) = ${fica_med:.2f}')
print()
print(f'Total FICA = ${fica_total:.2f}')
print()

# Calculate witholding (assume 20% of gross-FICA)
withholding_rate = 0.20
adjusted_income = gross_earnings - fica_total

withholding = adjusted_income * withholding_rate
# Calculate paycheck (net)
net_pay = gross_earnings - (fica_total + withholding)
# Print all results: gross, FICA, withholding, net paycheck
print(f'Your gross earnings is ${gross_earnings}, Your FICA total is ${fica_total}, your witholding is ${withholding}, and your net paycheck is {net_pay}')

'''
___________________________________________________________________
LEVEL UP REQUIREMENTS
You do not need to calculate witholding based on table.
-------------------------------------------------------------------
'''
# Ask user for hourly wage and hours worked
# You will need to cast this to a float!


# Calculate gross earnings.


# Calculate social security and medicare contribution.


# Calculate ANNUAL adjusted income.


# Calculate annual witholding based on provided table.


# Calculate paycheck (net)


# Print all calculated results.
# All values should have $ and appropriate commas






