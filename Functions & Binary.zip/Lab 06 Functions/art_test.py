from ascii_art import *

def user_rectangle():
    width = int(input('Width of rectangle? '))
    height = int(input('Height of rectangle? '))
    print('\nHere is your rectangle ...',end='\n')
    draw_rectangle(width,height)

def user_triangle():
    height = int(input('\nHeight of triangle? '))
    print('\nHere is your triangle ...',end='\n')
    draw_triangle(height)

def user_number():
    number = int(input('\nWhat number do you want to draw? '))
    functions = [draw_zero,draw_one,draw_two,draw_three,draw_four,draw_five]
    functions += [draw_six,draw_seven,draw_eight,draw_nine]
    print('\nHere is your number...\n')
    functions[number]()


if __name__=="__main__":
    user_rectangle()
    user_triangle()
    user_number()

    
