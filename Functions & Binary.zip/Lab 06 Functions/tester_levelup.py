from functions_levelup import *

def test_get_ints():
    alist = get_integer_list()
    print(f'Got these integers: {alist}')

def test_convert():
    for i in range(1,13):
        m = convert_to_month(i)
        print(f'{i} is month {m}')

def test_binary():
    for i in range(0,16):
        b = convert_to_binary(i)
        print(f'{i} in binary is {b}')

test_get_ints()
test_convert()
test_binary()



