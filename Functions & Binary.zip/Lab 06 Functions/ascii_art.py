def draw_row(width):
    # print a row of a character of the specified width
    print('x' * width)
    pass

def draw_column(offset):
    # print a single character offset by specified amount
    char = 'x'
    print(' ' * offset + char)

    pass

def draw_border(spaces):
    # print a character followed by specified spaces, then another character
    print("x" + " " * spaces + "x")
    pass


def draw_rectangle(width,height):
    # print a rectangle using draw_row
    for _ in range(height):
        draw_row(width)
    pass
    
def draw_triangle(height):
    # print a (half) triangle using draw_row
    for i in range(1, height + 1):
        draw_row(i)
    pass

def draw_zero():
    # use the functions above to print an ascii art 0
    draw_row(4)
    draw_border(2)
    draw_border(2)
    draw_border(2)
    draw_row(4)
    pass

def draw_one():
    # use the functions above to print an ascii art 1
    pass

def draw_two():
    # use the functions above to print an ascii art 1
    pass

def draw_three():
    # use the functions above to print an ascii art 1
    pass

def draw_four():
    # use the functions above to print an ascii art 1
    pass

def draw_five():
    # use the functions above to print an ascii art 1
    pass

def draw_six():
    # use the functions above to print an ascii art 1
    pass

def draw_seven():
    # use the functions above to print an ascii art 1
    pass

def draw_eight():
    # use the functions above to print an ascii art 1
    pass

def draw_nine():
    # use the functions above to print an ascii art 1
    draw_row(4)
    draw_border(2)
    draw_border(2)
    draw_row(4)
    draw_column(3)
    draw_column(3)
    draw_column(3)
    pass


draw_row(5)
print()
draw_column(5)
print()
draw_border(3)
print()
draw_rectangle(3,4)
print()
draw_triangle(4)
print()
draw_zero()
print()
draw_nine()


