# COMMENT YOUR CODE PLEASE

def get_valid_input(alist):
    while True:
        #asks the user to enter something from the list in other file
        user = input("Enter Something from the list:")
        if user in alist:
            #if the input is right, return it
            return user
        else:
            # if the input is not right, print Not Accepted
            print('Not Accepted')
    pass

def sum_up_to(x):
    total = 0 #store the sum
    for i in range(1, x + 1): #start from 1 to x
        total += i #add each number to the total
    return total #the final sum
    pass

def season(month):
    month = month.capitalize() # capitazlie the first letter of the month name so the month names in the list properly reads it as the same
    seasons = {'Jan' : 'Winter', 'Feb': 'Winter', 'Mar':'Spring', 'Apr':'Spring', 'May':'Spring', 'Jun':'Summer','Jul':'Summer','Aug':'Summer','Sep':'Fall','Oct':'Fall','Nov':'Fall','Dec':'Winter'}
    return seasons[month] if month in seasons else 'not a month'
#returns the correct month and season but if its not, itll print not a month
    pass


        
    
    
