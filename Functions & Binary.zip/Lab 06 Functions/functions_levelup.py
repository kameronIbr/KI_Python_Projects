def get_integer_list():
    integer_list = []
    while True:
        user_input = input("Enter a number (type exit to stop): ")
        if user_input == 'exit':
            break
        if user_input.isdigit():
            num = int(user_input)
            integer_list.append(num)
        else:
            print("Invalid input. Please enter a valid integer or 'exit'.")
    return integer_list

def convert_to_month(number):
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
    return months[number - 1]

def convert_to_binary(number):
    binary_str = ''
    if number == 0:
        return '0'
    while number > 0:
        remainder = number % 2
        binary_str = str(remainder) + binary_str
        number = number // 2
    return binary_str
