from functions_base import *

def test_get_valid():
    A = ['a','list','of','words']
    value = get_valid_input(A)
    print(f"get_valid from {A} with result '{value}'")
   
def test_sum_up():
    total = sum_up_to(5)  # 1+2+3+4+5 = 15
    print(f'sum_up_to 5, expect 15. Result is {total}.')

def test_seasons():
    for month in ['jan','Feb','mar','May','jul','Oct','dec']:
        s = season(month)
        print(f'{month} is part of season {s}')


test_get_valid()
test_sum_up()
test_seasons()




